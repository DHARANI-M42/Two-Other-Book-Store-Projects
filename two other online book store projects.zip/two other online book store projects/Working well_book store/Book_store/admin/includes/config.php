<?php 
$conn=mysqli_connect("localhost","root","","book_store")or die("Can't Connect...");
	
?>